#FastGettext.add_text_domain 'app',
#	    :path => File.join(RAILS_ROOT, 'locale')