#suggestion
#HoptoadNotifier.configure do |config|
#  config.api_key = '5f8f99cc9c55dfafa691063f2832e967'
#end
#HoptoadNotifier.configure do |config|
#  config.api_key = '85f4c74fa1bfacae5e9995c793b0777d'
#end

