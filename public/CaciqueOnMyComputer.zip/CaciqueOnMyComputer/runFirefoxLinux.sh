#!/bin/bash
java -jar selenium-server-1.0.3/selenium-server.jar -firefoxProfileTemplate $HOME/perfil -forcedBrowserMode *firefox -singleWindow
