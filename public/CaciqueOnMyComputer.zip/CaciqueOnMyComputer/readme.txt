Requisitos:
- La version de java debe ser mayor o igual a la 1.5.X (java -version desde la consola de windows para ver la version)


Para usar bender en mi pc, se debe:
1- Hacer click en ambos links de clickers (clicker.exe y fireclicker.exe)
2- Luego hacer click en (run.bat)
