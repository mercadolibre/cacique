Requirements:
- The Java version must be greater than or equal to the 1.5.X (java-version from the console windows to see the version)

To use Cacique on my pc, you must click on run*.bat
